#pragma once
#include "elt.h"	// T_elt
#include "list_v2.h"	// T_list, T_node
#include <stdlib.h>
#include <string.h>


void generatePNG(const T_list l, const char * filename);
T_list exempleList();
T_list genList();
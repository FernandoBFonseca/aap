#pragma once
#include "elt.h"	// T_elt
#include "list_v2.h"	// T_list, T_node

void test();
#include <assert.h>

//#define CLEAR2CONTINUE
#include "../include/traces.h" 

//#define DEBUG
#include "../include/check.h"

#include "elt.h" // T_elt 
#include "list.h" // prototypes 

/*
typedef struct node {
	T_elt data;
	struct node *pNext;
} T_node, * T_list;
*/

static T_node * newNode(T_elt e) {
	// Créer une nouvelle cellule contenant l'élément e

	TOUCH_HERE("Ben là, c'est à vous ! \n");
	return NULL; 
}

T_node * addNode (T_elt e, T_node * n) {
	// Créer une maille (node), la remplir 
	// et l'accrocher en tête d'une liste existante (ou vide)
	// Renvoyer la nouvelle tête
 
	TOUCH_HERE("Ben là, c'est à vous ! \n");
	return NULL;
}

void showList(T_list l) {
	// Afficher la liste en commençant par sa tête 
	// A faire en itératif 

	TOUCH_HERE("Ben là, c'est à vous ! \n");
}

void freeList(T_list l) {
	// Libérer la mémoire de toutes les cellules de la liste l 
	// A faire en itératif

	TOUCH_HERE("Ben là, c'est à vous ! \n");
}

T_elt getFirstElt(T_list l) {
	// Renvoyer l'élément contenu dans la cellule de tête de la liste

	T_elt e; 
	TOUCH_HERE("Ben là, c'est à vous ! \n");

	return e; 
}

T_list removeFirstNode(T_list l) {
	// Supprimer la tête de la liste 
	// Renvoyer la nouvelle liste privée de sa première cellule

	TOUCH_HERE("Ben là, c'est à vous ! \n");

	return NULL; 
}

// A produire en version récursive (+ tard dans le sujet)

void showList_rec(T_list l) {
	// Afficher la liste en commençant par sa tête 
	// A faire en récursif 

	TOUCH_HERE("Ben là, c'est à vous ! \n");
}

void showList_inv_rec(T_list l) {
	// Afficher la liste en commençant par sa queue 
	// A faire en récursif 

	TOUCH_HERE("Ben là, c'est à vous ! \n");
}

void freeList_rec(T_list l) {
	// Libérer la mémoire de toutes les cellules de la liste l 
	// A faire en récursif

	TOUCH_HERE("Ben là, c'est à vous ! \n");
}


#! /bin/bash 

for i in $(seq 1 25)
do
echo -ne "$i)\t"
./ex_cesar.exe $i "SV PKED ZBOXNBO K MOCKB DYED MO AES XO VES KZZKBDSOXD ZKC. - Zkev OVEKBN OD Kxnbo LBODYX -"
done

